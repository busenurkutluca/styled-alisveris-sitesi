/* ADIM 1: Reactstrap Carousel'i burada oluşturabilirsin */
